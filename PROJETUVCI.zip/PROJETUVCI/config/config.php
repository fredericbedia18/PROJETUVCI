<?php
// Paramètres de connexion à la base de données
$servername = "localhost";  // L'adresse du serveur MySQL
$username = "root";         // Nom d'utilisateur MySQL (en local, c'est souvent 'root')
$password = "";             // Mot de passe MySQL (vide en local si tu n'as pas défini de mot de passe)
$dbname = "PROJETUVCI"; // Nom de ta base de données

// Création de la connexion à la base de données
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($mysqli->connect_error) {
    die("Erreur de connexion : " . $mysqli->connect_error);  // Si la connexion échoue, afficher l'erreur
}

// Optionnel : définir le jeu de caractères pour éviter des problèmes d'encodage
$mysqli->set_charset("utf8");
