<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INTELEC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- En-tête -->
    <header class="bg-dark text-white text-center p-4">
        <h1>BIENVENUE A INTELEC</h1>
        <nav>
            <ul class="nav justify-content-center">
                <li class="nav-item">
                    <a class="nav-link text-white" href="#accueil">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="#services">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="#contact">Contact</a>
                <li class="nav-item">
                    <a class="nav-link text-white" href="/PROJETUVCI/view/connexion.php">Connexion</a>
                </li>
                </li>
            </ul>
        </nav>
    </header>

    <!-- Section principale -->
    <main class="container mt-5">
        <section id="accueil" class="mb-5">
            <h2 class="text-primary">Présentation</h2>
            <p class="lead">L'EXELLENCE A VOTRE PORTE.</p>
        </section>

        <section id="services" class="mb-5">
            <h2 class="text-primary">Nos Services</h2>
            <ul class="list-group">
                <li class="list-group-item">Création de sites web</li>
                <li class="list-group-item">Formation en développement</li>
                <li class="list-group-item">Conseil en technologies numériques</li>
            </ul>
        </section>

        <section id="contact">
            <h2 class="text-primary">Contactez-nous</h2>
            <form>
                <div class="mb-3">
                    <label for="nom" class="form-label">Nom :</label>
                    <input type="text" id="nom" class="form-control" placeholder="Votre nom">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email :</label>
                    <input type="email" id="email" class="form-control" placeholder="Votre email">
                </div>
                <button type="submit" class="btn btn-primary">Envoyer</button>
            </form>
        </section>
    </main>

    <!-- Pied de page -->
    <footer class="bg-dark text-white text-center p-4 mt-5">
        <p>&copy; 2025 Mon Projet Web</p>
    </footer>

    <!-- Script JavaScript Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>