<?php
// 1. Vérification de la présence du mot de passe dans la requête POST
if (isset($_POST['mot_de_passe']) && !empty($_POST['mot_de_passe'])) {
    // Récupération du mot de passe
    $mot_de_passe = $_POST['mot_de_passe'];
} else {
    // Si le mot de passe est manquant, afficher un message d'erreur
    echo "Le mot de passe est requis.";
    exit;  // Arrêter le script ici
}

// 2. Hachage du mot de passe
$hashed_password = password_hash($mot_de_passe, PASSWORD_BCRYPT);
if ($hashed_password === false) {
    // Si le hachage échoue, afficher un message d'erreur
    echo "Erreur lors du hachage du mot de passe.";
    exit;
}

// 3. Connexion à la base de données MySQL
$mysqli = new mysqli('localhost', 'root', '', 'projet_connexion');

// Vérification de la connexion à MySQL
if ($mysqli->connect_error) {
    die('Erreur de connexion : (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

// 4. Insertion des données dans la base de données
if (isset($_POST['nom']) && isset($_POST['email'])) {
    // Récupérer les autres données du formulaire
    $nom = $_POST['nom'];
    $email = $_POST['email'];

    // Préparer la requête pour insérer les données dans la table (exemple : table 'utilisateurs')
    $stmt = $mysqli->prepare("INSERT INTO utilisateurs (nom, email, mot_de_passe) VALUES (?, ?, ?)");
    if ($stmt === false) {
        // Si la préparation échoue
        echo "Erreur de préparation de la requête.";
        exit;
    }

    // Lier les paramètres à la requête préparée
    $stmt->bind_param("sss", $nom, $email, $hashed_password);

    // Exécuter la requête
    if ($stmt->execute()) {
        echo "L'utilisateur a été enregistré avec succès.";
    } else {
        echo "Erreur lors de l'enregistrement : " . $stmt->error;
    }

    // Fermer la requête préparée
    $stmt->close();
} else {
    echo "Les champs 'nom' et 'email' sont requis.";
}

// 5. Fermer la connexion à la base de données
$mysqli->close();
