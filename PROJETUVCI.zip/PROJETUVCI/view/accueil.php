<?php
session_start();

if (!isset($_SESSION['utilisateur'])) {
    // Redirige vers la page de connexion si l'utilisateur n'est pas connecté
    header('Location: connexion.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page d'accueil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Mon Projet</a>
            <div class="d-flex">
                <a href="deconnexion.php" class="btn btn-danger">Déconnexion</a>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="text-center">Bienvenue, <?php echo htmlspecialchars($_SESSION['utilisateur']); ?> !</h1>
        <p class="text-center">Vous êtes connecté sur la page d'accueil.</p>
    </div>
</body>

</html>